| Suite | Points | Score | Pass / Partial / Fail |
|---|---:|---:|---:|
| Basic | 118/138 | 85.51% | 55 / 8 / 6 |
| Hard | 32/38 | 84.21% | 15 / 2 / 2 |
| Total | 150/176 | 85.23% | 70 / 10 / 8 |
