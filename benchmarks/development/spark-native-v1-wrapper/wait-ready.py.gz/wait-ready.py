import datetime,json,os,subprocess,time,urllib.request
from pathlib import Path
os.environ['SSH_AUTH_SOCK']=str(Path.home()/'.ssh/agent/s.KCgk0ZT1TX.sshd.GmDOKSZakq')
p=Path('.cache/release/spark-gc-parent-provenance')
for _ in range(240):
    try:
        if urllib.request.urlopen('http://10.55.1.5:8000/health',timeout=2).status==200:break
    except Exception:pass
    time.sleep(5)
else:raise RuntimeError('Parent readiness deadline; inspect without automatic restart')
for rank,(host,container) in enumerate([('rhea','dots3-vllm-head'),('moa','dots3-vllm-worker')]):
    raw=subprocess.check_output(['ssh',host,'cat',f'/home/tj/dots-note-work/serving/cache/allocator-policy-rank{rank}.json'],text=True)
    policy=json.loads(raw)
    info=json.loads(subprocess.check_output(['ssh',host,'docker','inspect',container],text=True))[0]
    started=datetime.datetime.fromisoformat(info['State']['StartedAt'].replace('Z','+00:00')).timestamp()
    assert policy['rank']==rank and policy['world_size']==2
    assert policy['allocator_backend']=='native' and abs(policy['per_process_fraction']-.9)<1e-8
    assert policy['settings']['garbage_collection_threshold']==.9 and policy['created_at_unix']>=started
    assert info['Image']=='sha256:bc959336ec2a3db42e6a50309326aadac8c054d7ff7b0840cf402abf0e2d80e9'
    (p/f'policy-{host}.json').write_text(raw)
    (p/f'container-{host}.json').write_text(json.dumps(info,indent=2))
    subprocess.run(['ssh',host,'bash','-s'],input=f'cd /home/tj/dots-note-work/recipe\nmkdir -p .cache/release/spark-gc-parent\npython3 serving/capture_runtime.py {container} --output .cache/release/spark-gc-parent/runtime-{host}.json\n',text=True,check=True)
    subprocess.run(['scp',f'{host}:/home/tj/dots-note-work/recipe/.cache/release/spark-gc-parent/runtime-{host}.json',str(p/f'runtime-{host}.json')],check=True)
print('PRODUCTION_PARENT_READY_POLICY_AND_IDENTITY_VERIFIED',flush=True)
