import concurrent.futures,json,os,subprocess,time,urllib.request
from pathlib import Path
os.environ["SSH_AUTH_SOCK"]=str(Path.home()/".ssh/agent/s.KCgk0ZT1TX.sshd.GmDOKSZakq")
def read(host):
 c=subprocess.run(["ssh","-o","BatchMode=yes",host,"tail -1 /home/tj/dots-note-work/serving/cache/memory-watch.log"],text=True,capture_output=True,timeout=10)
 return host,json.loads(c.stdout)
with open(".cache/serving/spark/diagnostic-external.jsonl","a",buffering=1) as out:
 for _ in range(240):
  with concurrent.futures.ThreadPoolExecutor(2) as pool: rows=dict(pool.map(read,["rhea","moa"]))
  result={"time":time.time(),"hosts":rows}
  try:
   text=urllib.request.urlopen("http://10.55.1.5:8000/metrics",timeout=3).read().decode()
   result["metrics"]=[x for x in text.splitlines() if not x.startswith("#") and any(k in x for k in ["kv_cache_usage_perc","num_requests_running","prompt_tokens_total"])]
  except Exception as e:result["metrics_error"]=repr(e)
  out.write(json.dumps(result)+"\n")
  if any(x.get("available_bytes",2**40)<2*2**30 for x in rows.values()):
   out.write(json.dumps({"event":"diagnostic-stop-before-guard","time":time.time()})+"\n")
   with concurrent.futures.ThreadPoolExecutor(2) as pool:
    list(pool.map(lambda item:subprocess.run(["ssh",item[0],"docker","stop","--time","5",item[1]],capture_output=True),[("rhea","dots3-vllm-head"),("moa","dots3-vllm-worker")]))
   break
  time.sleep(5)
