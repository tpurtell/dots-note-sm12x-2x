import json,os,subprocess,time,urllib.request
from pathlib import Path
root=Path(".cache/serving/spark")
os.environ["SSH_AUTH_SOCK"]=str(Path.home()/".ssh/agent/s.KCgk0ZT1TX.sshd.GmDOKSZakq")
for _ in range(240):
 try:
  if urllib.request.urlopen("http://10.55.1.5:8000/health",timeout=2).status==200: break
 except Exception:pass
 time.sleep(5)
else:raise RuntimeError("GC candidate did not become ready within20min; inspect, do notrestart")
receipts={}
for host,name in [("rhea","dots3-vllm-head"),("moa","dots3-vllm-worker")]:
 r=subprocess.run(["ssh",host,"docker","logs",name],capture_output=True,text=True,check=True)
 logs=r.stdout+r.stderr
 (root/f"diagnostic-gc90-postwarm-{host}-startup.log").write_text(logs)
 rows=[json.loads(line.split("DOTS3_ALLOCATOR_POLICY ",1)[1]) for line in logs.splitlines() if "DOTS3_ALLOCATOR_POLICY {" in line]
 assert len(rows)==1,rows
 assert abs(rows[0]["per_process_fraction"]-.9)<1e-8 and rows[0]["settings"]["garbage_collection_threshold"]==.9
 receipts[host]=rows[0]
(root/"diagnostic-gc90-postwarm-policy.json").write_text(json.dumps(receipts,indent=2))
print("HEALTH200 bothpolicyreceiptsvalidated; startingfailedboundaryretest",flush=True)
monitor=subprocess.Popen(["python3",str(root/"monitor-diagnostic-gc90.py")])
(root/"diagnostic-gc90-monitor.pid").write_text(str(monitor.pid))
try:
 with (root/"context-diagnostic-gc90-postwarm-524.log").open("w") as out:
  r=subprocess.run(["python3","serving/benchmarks/context.py","--base-url","http://10.55.1.5:8000","--depths","524032","--output-tokens","256","--runs","1","--warmups","0","--output",str(root/"context-diagnostic-gc90-postwarm-524.jsonl")],stdout=out,stderr=subprocess.STDOUT)
 print("BOUNDARY_RETURN",r.returncode,flush=True)
finally:
 monitor.terminate();monitor.wait()
