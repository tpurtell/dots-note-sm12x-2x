#!/bin/bash
set -euo pipefail
host=$1
role=$2
export SSH_AUTH_SOCK="$HOME/.ssh/agent/s.KCgk0ZT1TX.sshd.GmDOKSZakq"
ssh -o BatchMode=yes "$host" bash -s -- "$role" <<'REMOTE'
set -euo pipefail
cd /home/tj/dots-note-work/recipe
docker rm "dots3-vllm-$1"
export IMAGE=dots3-vllm-spark:memory-diagnostic-gc90-postwarm GPU_MEMORY_UTILIZATION=0.80 MIN_HOST_AVAILABLE_GIB=1
export DOTS3_B12X_VOCAB=0 DOTS3_B12X_ROCE=1 B12X_ROCE_HCA=roceP2p1s0f0 B12X_ROCE_GID_INDEX=3
export MAX_MODEL_LEN=524288 MAX_BATCHED_TOKENS=512 DOTS3_COMPACT_DSA_CACHE=1 DOTS3_INDEXER_PREFILL_CONTEXTS=4
export VLLM_HYBRID_LAYER_PARTITION=17,29 VLLM_HYBRID_PACKED_ROUTING=1 VLLM_HYBRID_FUSED_PACK=1 VLLM_HYBRID_OVERLAP_SHARED=1
export VLLM_HYBRID_BALANCE_KV_GROUPS=1
export VLLM_HYBRID_MM_OWNERS=0,1 VLLM_HYBRID_BOUNDARY_OWNERS=
export VLLM_HYBRID_ATTESTATION_PATH=/root/.cache/vllm-runtime/memory-diagnostic-gc90-postwarm-attestation.json
export REASONING_PARSER=dots3 RUNTIME_CACHE=/home/tj/dots-note-work/serving/cache
bash serving/start_spark_node.sh --worker-extension-cls diagnostic_memory.MemoryDiagnosticWorkerExtension --speculative-config '{"method":"mtp","num_speculative_tokens":3}'
REMOTE
