import pathlib,json,os,sys,subprocess,time,urllib.request
p=pathlib.Path('.cache/release/rtx-native-v2').resolve()
name,image,folder=sys.argv[1:]
d=p/folder;d.mkdir(parents=True,exist_ok=False)
runtime=d/'runtime';runtime.mkdir()
env=os.environ|json.loads((p/'launch-profile.json').read_text())|{'IMAGE':image,'CONTAINER_NAME':name,'RUNTIME_CACHE':str(runtime)}
with (d/'start.log').open('x') as log:
 subprocess.run(['bash',str(p/'context/serving/start_rtx.sh'),'--speculative-config','{"method":"mtp","num_speculative_tokens":3}','--worker-extension-cls','hybrid_attestation.HybridAttestationWorkerExtension'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
(d/'container-launch.json').write_bytes(subprocess.check_output(['docker','inspect',name]))
for n in range(240):
 state=json.loads(subprocess.check_output(['docker','inspect',name]))[0]['State']
 if not state['Running']:raise RuntimeError(state)
 try:
  with urllib.request.urlopen('http://127.0.0.1:8001/health',timeout=2) as r:
   if r.status==200:break
 except Exception: pass
 if n%12==0:print('Waiting '+str(n*5)+' sec',flush=True)
 time.sleep(5)
else:raise RuntimeError('startup timeout')
subprocess.run(['python3','serving/capture_runtime.py',name,'--output',str(d/'runtime-start.json')],check=True)
print('READY '+name,flush=True)
