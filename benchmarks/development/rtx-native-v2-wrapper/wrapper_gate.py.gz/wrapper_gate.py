import pathlib,subprocess,json,time,urllib.request
p=pathlib.Path('.cache/release/rtx-native-v2/wrapper')
for _ in range(240):
 try:
  if urllib.request.urlopen('http://127.0.0.1:8001/health',timeout=2).status==200:break
 except Exception:pass
 time.sleep(5)
else:raise RuntimeError('health timeout')
for name,script,opts in [('api','serving/benchmarks/reasoning_api.py',['--repeats','1','--require-mtp']),('prefix','serving/qualify_prefix_xgrammar.py',[]),('multimodal','serving/benchmarks/multimodal.py',[])]:
 cmd=['python3',script,'--base-url','http://127.0.0.1:8001',*opts,'--output',str(p/(name+('.jsonl' if name=='api' else '.json')))];print('START '+name,flush=True)
 with (p/(name+'.log')).open('x') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE '+name,flush=True)
subprocess.run(['python3','serving/capture_runtime.py','dots3-vllm-rtx-v2-wrapper','--output',str(p/'runtime-end.json')],check=True)
with (p/'container-complete.log').open('x') as f:subprocess.run(['docker','logs','dots3-vllm-rtx-v2-wrapper'],stdout=f,stderr=subprocess.STDOUT,check=True)
(p/'container-complete.json').write_bytes(subprocess.check_output(['docker','inspect','dots3-vllm-rtx-v2-wrapper']))
print('WRAPPER GATE COMPLETE',flush=True)
