import json
import os
from pathlib import Path
import subprocess
import time
import urllib.request

root = Path.cwd()
out = root / '.cache/serving/rtx/hybrid'
image = 'sha256:0d2c3c4d7373b6c07d2ddd2a8b0a9856428560c2ef2c700ff6650867e5c89b81'
for cut in (18, 17):
    name = f'dots3-vllm-rtx-capacity-audit-{cut}'
    tag = f'capacity-audit-{cut}'
    env = {k:v for k,v in os.environ.items() if not k.startswith(('DOTS3_', 'VLLM_HYBRID_'))}
    env.update(CONTAINER_NAME=name, IMAGE=image, RUNTIME_CACHE=str(out/'runtime'),
        MAX_MODEL_LEN='524288', MAX_NUM_SEQS='16', MAX_BATCHED_TOKENS='512',
        GPU_MEMORY_UTILIZATION='.95', REASONING_PARSER='dots3',
        DOTS3_COMPACT_DSA_CACHE='1', DOTS3_INDEXER_PREFILL_CONTEXTS='4',
        VLLM_HYBRID_LAYER_PARTITION=f'{cut},{46-cut}', VLLM_HYBRID_PACKED_ROUTING='1',
        VLLM_HYBRID_MM_OWNERS='0,1', VLLM_HYBRID_FUSED_PACK='0',
        VLLM_HYBRID_OVERLAP_SHARED='0', VLLM_HYBRID_BOUNDARY_OWNERS='',
        VLLM_HYBRID_ATTESTATION_PATH=f'/root/.cache/vllm-runtime/ownership-{tag}.json')
    cmd = ['bash','serving/start_rtx.sh','--speculative-config',
        '{"method":"mtp","num_speculative_tokens":3}',
        '--worker-extension-cls','hybrid_attestation.HybridAttestationWorkerExtension']
    with (out/f'start-{tag}.log').open('x') as f:
        subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
    for i in range(120):
        status=subprocess.check_output(['docker','inspect','--format','{{.State.Status}}',name],text=True).strip()
        if status!='running':raise RuntimeError(f'{name}: {status}')
        try:
            with urllib.request.urlopen('http://127.0.0.1:8001/health',timeout=2) as r:
                if r.status==200:break
        except Exception:pass
        if i%6==0:print(f'{tag}: waiting for startup',flush=True)
        time.sleep(5)
    else:raise RuntimeError(f'{name}: observation timeout; inspect this existing container')
    subprocess.run(['python3','serving/capture_runtime.py',name,'--output',str(out/f'runtime-{tag}.json')],check=True)
    receipt=json.loads((out/'runtime'/f'ownership-{tag}.json').read_text())
    if not receipt['passed']:raise RuntimeError('ownership check failed')
    print(json.dumps({'tag':tag,'workers':[{k:v for k,v in w.items()
        if k in ('rank','available_kv_cache_memory_bytes','memory_profile','unique_kv_storage_bytes')}
        for w in receipt['workers']]}),flush=True)
    with (out/f'prefix-{tag}.log').open('x') as f:
        subprocess.run(['python3','serving/qualify_prefix_xgrammar.py','--base-url',
            'http://127.0.0.1:8001','--output',str(out/f'prefix-{tag}.json')],
            stdout=f,stderr=subprocess.STDOUT,check=True)
    with (out/f'startup-{tag}.log').open('x') as f:
        subprocess.run(['docker','logs',name],stdout=f,stderr=subprocess.STDOUT,check=True)
    with (out/f'container-{tag}.json').open('x') as f:
        subprocess.run(['docker','inspect',name],stdout=f,check=True)
    subprocess.run(['docker','stop',name],check=True)
    print(f'{tag}: complete, stopped',flush=True)
