import hashlib,json,os,pathlib,shlex,subprocess,sys,time,urllib.request

ROOT=pathlib.Path.cwd(); OUT=ROOT/'.cache/release/spark-v1-fastpath'
REMOTE='/home/tj/dots-note-work/recipe'
RUNTIME=REMOTE+'/.cache/release/spark-v1-fastpath-runtime'
REPORT=pathlib.Path('benchmarks/releases/spark-20260925-v1/report.json')
SETTINGS=pathlib.Path('serving/release/settings.json')
sys.path.insert(0,str(ROOT/'serving/release'))
from report import spark_allocator_policies
from run import settings,validate_existing_container

assert list((ROOT/'.cache/release/spark-v1-qualification').glob('attempt-*/complete.json'))
config=settings(SETTINGS,'spark');OUT.mkdir(exist_ok=False)
events=[]

def ssh(host,command):
    return subprocess.check_output(['ssh','-o','BatchMode=yes',host,command],stderr=subprocess.STDOUT)

def remote_env(host):
    return {'NODE_RANK':'0' if host=='rhea' else '1','HOST_IP':'10.55.1.5' if host=='rhea' else '10.55.1.6',
            'MASTER_ADDR':'10.55.1.5','SOCKET_IFNAME':'enP2p1s0f0np0','B12X_ROCE_HCA':'roceP2p1s0f0',
            'B12X_ROCE_GID_INDEX':'3','RUNTIME_CACHE':RUNTIME,'HF_HOME':'/home/tj/.cache/huggingface'}

def command(host,action):
    env=' '.join(shlex.quote(k+'='+v) for k,v in remote_env(host).items())
    return 'cd '+shlex.quote(REMOTE)+' && env '+env+' bash serving/release/run.sh spark '+action

def action(host,name,label=None):
    started=time.time();data=ssh(host,command(host,name));(OUT/f'{label or name}-{host}.log').write_bytes(data)
    events.append({'host':host,'action':name,'label':label,'started':started,'finished':time.time(),'passed':True})
    print('DONE',host,name,flush=True)

def capture(label):
    runtimes={}
    for host in ('rhea','moa'):
        name='dots3-vllm-head' if host=='rhea' else 'dots3-vllm-worker'
        destination=REMOTE+f'/.cache/release/spark-fastpath-{label}-{host}.json'
        ssh(host,'cd '+shlex.quote(REMOTE)+' && python3 serving/capture_runtime.py '+shlex.quote(name)+' --output '+shlex.quote(destination))
        raw=ssh(host,'cat '+shlex.quote(destination));(OUT/f'{label}-runtime-{host}.json').write_bytes(raw)
        runtimes[host]=json.loads(raw)
        inspect=json.loads(ssh(host,'docker inspect '+name))[0]
        validate_existing_container(inspect,config,'spark')
        (OUT/f'{label}-inspect-{host}.json').write_text(json.dumps(inspect,indent=2)+'\n')
        guard=ssh(host,'cat '+shlex.quote(RUNTIME+'/memory-watch.pid')).decode().strip()
        cmdline=ssh(host,'ps -p '+str(int(guard))+' -o args=').decode().strip()
        assert 'watch_spark_memory.py' in cmdline and name in cmdline
        (OUT/f'{label}-guard-{host}.json').write_text(json.dumps({'pid':int(guard),'command':cmdline})+'\n')
    spark_allocator_policies(runtimes)

def healthy(label):
    deadline=time.monotonic()+1800
    while time.monotonic()<deadline:
        for host,name in [('rhea','dots3-vllm-head'),('moa','dots3-vllm-worker')]:
            state=json.loads(ssh(host,'docker inspect --format '+shlex.quote('{{json .State}}')+' '+name))
            assert state['Running'],(host,state)
        try:
            if urllib.request.urlopen('http://10.55.1.5:8000/health',timeout=3).status==200:break
        except Exception:pass
        time.sleep(10)
    else:raise RuntimeError('Spark startup did not become healthy within30minutes')
    action('rhea','health',label+'-health');capture(label)
    print('HEALTHY',label,flush=True)

files=[str(REPORT),str(SETTINGS),'serving/release/run.py','serving/release/run.sh','serving/start_spark_node.sh','serving/watch_spark_memory.py','serving/capture_runtime.py']
for host in ('rhea','moa'):
    producer=subprocess.Popen(['tar','-cf','-',*files],stdout=subprocess.PIPE)
    subprocess.run(['ssh','-o','BatchMode=yes',host,'tar -xf - -C '+shlex.quote(REMOTE)],stdin=producer.stdout,check=True)
    producer.stdout.close();assert producer.wait()==0
    ssh(host,'test ! -e '+shlex.quote(RUNTIME)+' && mkdir -p '+shlex.quote(RUNTIME))
action('rhea','stop','qualification-stop');action('moa','stop','qualification-stop')
action('rhea','remove');action('moa','remove')
for host in ('moa','rhea'):action(host,'pull');action(host,'start')
healthy('first')
for host in ('rhea','moa'):
    action(host,'status')
    completed=subprocess.run(['ssh','-o','BatchMode=yes',host,'timeout 2s bash -c '+shlex.quote(command(host,'logs'))],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert completed.returncode==124,completed
    (OUT/f'logs-{host}.log').write_bytes(completed.stdout)
    events.append({'host':host,'action':'logs','passed':True,'follower_terminated_after_seconds':2})
action('rhea','stop');action('moa','stop')
action('moa','restart');action('rhea','restart');healthy('restarted')
for host in ('rhea','moa'):
    name='dots3-vllm-head' if host=='rhea' else 'dots3-vllm-worker'
    (OUT/f'container-final-{host}.log').write_bytes(ssh(host,'docker logs '+name))
    (OUT/f'guard-final-{host}.log').write_bytes(ssh(host,'cat '+shlex.quote(RUNTIME+'/memory-watch.log')))
receipt={'schema':'dots3-spark-public-lifecycle-v1','passed':True,'image':config['image'],
         'qualification_report':str(REPORT),'qualification_report_sha256':hashlib.sha256(REPORT.read_bytes()).hexdigest(),
         'initial_runtime_empty':True,'model_downloaded':False,'benchmark_requests_sent':0,
         'temperature_power_cooling_changes':False,'events':events,'ended_running':True,
         'allocator_policy_validated_on_both_hosts_after_each_start':True}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('LIFECYCLE COMPLETE',flush=True)
