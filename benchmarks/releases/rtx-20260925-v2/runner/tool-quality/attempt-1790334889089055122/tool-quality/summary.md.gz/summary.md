| Suite | Points | Score | Pass / Partial / Fail |
|---|---:|---:|---:|
| Basic | 116/138 | 84.06% | 51 / 14 / 4 |
| Hard | 31/38 | 81.58% | 14 / 3 / 2 |
| Total | 147/176 | 83.52% | 65 / 17 / 6 |
